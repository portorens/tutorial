<?php
ini_set('display_errors','On');
error_reporting('E_ALL');


require(dirname(__FILE__).'/require/classes.php');
$sourse = new Tempel('main');


?>