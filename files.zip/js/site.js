$(document).ready(function(){
 
    $("#create_cards").validate({
  
       rules:{ 
 
            series:{
                required: true,
                minlength: 3,
                maxlength: 6,
                
            },
            
            cols:{
            	required: true,
                digits: true,
                minlength: 1,
                
            },
            
            activity_period:{
            	required: true,
                
                
            },
            
            
            
            

 
       },
 
       messages:{
 
            series:{
                required: " Это поле обязательно для заполнения",
                minlength: " Серия должна состоять минимум из 3 символов",
                maxlength: " Максимальное число символов в серии 6",
            },
 
           cols:{
                required: " Это поле обязательно для заполнения", // сообщение для имени, если поле не заполнено
                digits: " Это поле должно содержать только цифры",
                minlength: " Минимальная длина поля 1 цифра",
            },
            
            activity_period:{
                required: " Это поле обязательно для заполнения", // сообщение для имени, если поле не заполнено
               
            },
 
       }
 
    });
    
        $("#create_purchase").validate({
       rules:{ 
 
            id:{
                required: true,
                digits: true,
                minlength: 1,
                
            },
            
            sum:{
            	required: true,
                digits: true,
                minlength: 1,
                
            },
            
            name:{
            	required: true,
                minlength: 5,
                maxlength: 20,
                
                
            },
            
            
            
            

 
       },
       messages:{
 
            id:{
                required: " Это поле обязательно для заполнения",
                digits: " Это поле должно содержать только цифры",
                minlength: " Номер карты должен состоять минимум из 1 цифры",
            },
 
           sum:{
                required: " Это поле обязательно для заполнения", 
                digits: " Это поле должно содержать только цифры",
                minlength: " Минимальная длина суммы 1 цифра",
            },
            
            name:{
                required: " Это поле обязательно для заполнения",
                minlength: " Минимальное название покупки должно состоять из 5 символов",
                maxlength: " Максимальное название покупки должно быть не более 20 символов",
               
            },
 
       }
 
    });

 
});