<?php
	//инициализация таблицы покупок
	
	$massfiles = array ("name" => "покупки",
	"tpl"=>"index.php",
	"sub_menu"=>"sub_menu.php",
	"adr"=>"index",
	"need_to_create_button"=>"yes",
	"onpage"=>"40",
	"search"=>"yes",
	"rules"=>"all",
	"default"=>"no",
	"inrazdel"=>"",
	"filtersusers"=>"no",
	"dopSQL"=>" ORDER BY `id` DESC",
	"dopWHERE"=>' `cards_id` = "'.$this->mysqli->real_escape_string($_GET['edit']).'" ',
	"onoff"=>"on");
	
	
	$sortirovka[] = array("stolb"=>"id", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"id");
	$sortirovka[] = array("stolb"=>"name", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"название покупки");
	$sortirovka[] = array("stolb"=>"date_purchase", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"дата покупки");
	$sortirovka[] = array("stolb"=>"sum", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"сумма покупки");
	
	$temper_data = $this->admin_vkladka($this->sh.'purchase', '', $massfiles, $massfiles['dopSQL'], $dopWHERE, $sortirovka);

?>
