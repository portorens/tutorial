<?php
	//создание покупки
	
	if (isset($_POST['do']) && $_POST['do']=='new_purchase') {
		$stop_work = 0;
		//валидация входящий значений
		
		//серия
		if (!isset($_POST['series']) || trim($_POST['series'])=='') {
			$this->message_alert .= 'не указана серия карт<br>';
			$stop_work = 1;
		}
		else {
			$_POST['series'] = strtolower($_POST['series']);
			preg_match('|^([a-z0-9]{3,6})$|', $_POST['series'], $result_preg);
			if (!isset($result_preg[1])) {
				$this->message_alert .= 'в поле серия разрешены только латинские символы и цифры<br>';
				$stop_work = 1;
			}
		}
		
		//название покупки
		if (!isset($_POST['name']) || trim($_POST['name'])=='') {
			$this->message_alert .= 'не указано название покупки<br>';
			$stop_work = 1;
		}
		else {
			$_POST['name'] = strtolower($_POST['name']);
			preg_match('|^(.*){3,6}$|', $_POST['name'], $result_preg);
			
			if (!isset($result_preg[0])) {
				$this->message_alert .= 'Пожалуйста укажите корректно название покупки<br>';
				$stop_work = 1;
			}
		}
		
		$_POST['id'] = (int) $_POST['id'];
		if ($_POST['id']==0) {
			$this->message_alert .= 'Пожалуйста укажите корректно номер карты<br>';
			$stop_work = 1;
		}
		
		$_POST['sum'] = (int) $_POST['sum'];
		if ($_POST['sum']==0) {
			$this->message_alert .= 'Пожалуйста укажите корректно сумму покупки<br>';
			$stop_work = 1;
		}
		
		if ($stop_work==0) {
			$row_cards = $this->mysqli->query('SELECT `id`, `procent`, `grid_id`, `date_expires`-NOW() as findexpire FROM `'.$this->sh.'cards` WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['id']).'" LIMIT 1 FOR UPDATE');
			if ($row_cards->num_rows==0) {
				$this->message_alert .= 'указанная вами карта не найдена<br>';
			}
			else {
				$result_cards = $row_cards->fetch_assoc();
				
				switch ($result_cards['grid_id']) {
				case 1:
				    $this->message_alert .= 'Невозможно оформить покупку, так как карта не активирована<br>';
				    
				    break;
				case 2:
					if ($result_cards['findexpire']<0) {
						//срок жизни карты истек - блокируем ее
						$this->mysqli->query('UPDATE `'.$this->sh.'cards` SET `grid_id` = "3", `grid` = (SELECT `name` FROM `c_grid` WHERE `id` = "3" ) WHERE `id` = "'.$result_cards['id'].'"' ) or $this->message_error = $this->mysqli->error;
						if ($this->message_error=='') {
							$this->mysqli->commit();
							$this->message_info = 'Срок работы карты истек. Карта заблокирована';
						}
						else $this->mysqli->rollback();	
					}
					else {
						//считаем процент начисления от суммы покупки
						$sum = ($_POST['sum']*$result_cards['procent'])/100;
				
						$this->mysqli->query('INSERT INTO `'.$this->sh.'purchase` 
												(
												`name`,
												`date_purchase`,
												`cards_id`,
												`sum`
												 ) 
											VALUES ("'.$this->mysqli->real_escape_string($_POST['name']).'", NOW(), "'.$result_cards['id'].'", "'.$this->mysqli->real_escape_string($_POST['sum']).'" )') or $this->message_error = $this->mysqli->error;
						
						$this->mysqli->query('UPDATE `'.$this->sh.'cards` SET `sum` = `sum`+ '.$sum.' WHERE `id` = '.$result_cards['id'] ) or $this->message_error = $this->mysqli->error;
											
						if ($this->message_error=='') {
							$this->mysqli->commit();
							$this->message_success = 'Покупка успешно создана';
						}
						else $this->mysqli->rollback();	
					}
				   
				    
				    break;
				case 3:
				    $this->message_alert .= 'Невозможно оформить покупку, так как карта просрочена<br>';
				    break;
				}

				
			}
		}
	}

?>