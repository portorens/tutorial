<?php
	//статус редактируемой карты
	
	$row_cards = $this->mysqli->query('SELECT `grid_id` FROM `'.$this->sh.'cards` WHERE `id` = "'.$this->mysqli->real_escape_string($_GET['edit']).'" ');
	if ($row_cards->num_rows==1) {
		$result_cards = $row_cards->fetch_assoc();
		
		
		$row_grid = $this->mysqli->query('SELECT `id`, `name` FROM `'.$this->sh.'grid` ORDER BY `id` ASC ');
		while ($result_grid = $row_grid->fetch_assoc()) {
			$temper_data_cukl = $temper_data;
			foreach ($result_grid as $result_menu_temper_key=>$result_menu_temper) {
				$temper_data_cukl = str_replace('[*'.$result_menu_temper_key.'*]', $result_menu_temper, $temper_data_cukl);
			}
		
			if ( $result_grid['id']==$result_cards['grid_id'] ) {
				$temper_data_cukl = str_replace('[*active*]', ' selected ', $temper_data_cukl);
			}
			else {
				$temper_data_cukl = str_replace('[*active*]', '', $temper_data_cukl);
			}
			
		
			$compile_code .= $temper_data_cukl;
		}
	$temper_data = $compile_code;
		
	} 
	
?>


