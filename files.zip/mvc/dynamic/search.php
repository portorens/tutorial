<?php
//поиск по карточкам

if (!isset($_GET['search']['series'])) $_GET['search']['series'] = '';
if (!isset($_GET['search']['grid'])) $_GET['search']['grid'] = '';
if (!isset($_GET['search']['activity_period'])) $_GET['search']['activity_period'] = '';

$temper_data = '<form role="search" action="/" method="get" class="navbar-form navbar-left">
            <div class="form-group">
              <input type="text" name="search[series]" value="'.$_GET['search']['series'].'" placeholder="Search - серия" class="form-control"><input name="search[grid]" value="'.$_GET['search']['grid'].'" type="text" placeholder="Search - статус карты" class="form-control"><input type="text" placeholder="Search - период работы" value="'.$_GET['search']['activity_period'].'" name="search[activity_period]" class="form-control">
            </div>
            <button class="btn btn-default" type="submit">найти</button>
          </form><div class="clearfix"></div>';
          
?>