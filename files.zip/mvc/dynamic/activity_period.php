<?php
	//генерация активных периодов

	$row_menu = $this->mysqli->query('SELECT `id`, `name` FROM `'.$this->sh.'activity_period` ORDER BY `id` ASC ');
	$compile_code = '';
	while ($result_menu = $row_menu->fetch_assoc()) {
		$temper_data_cukl = $temper_data;
		foreach ($result_menu as $result_menu_temper_key=>$result_menu_temper) {
			$temper_data_cukl = str_replace('[*'.$result_menu_temper_key.'*]', $result_menu_temper, $temper_data_cukl);
		}
		
		
		$compile_code .= $temper_data_cukl;
	}
	$temper_data = $compile_code;
?>