<?php
	//создание меню

	$row_menu = $this->mysqli->query('SELECT `id`, `name`, `alias` FROM `'.$this->sh.'contents` WHERE `in_menu` = "1" ORDER BY `id` ASC ');
	$compile_code = '';
	while ($result_menu = $row_menu->fetch_assoc()) {
		$temper_data_cukl = $temper_data;
		foreach ($result_menu as $result_menu_temper_key=>$result_menu_temper) {
			$temper_data_cukl = str_replace('[*'.$result_menu_temper_key.'*]', $result_menu_temper, $temper_data_cukl);
		}
		
		if ($this->request==$result_menu['alias'] || ($this->request=='' && $result_menu['alias']=='') ) {
			$temper_data_cukl = str_replace('[*active*]', 'class="active"', $temper_data_cukl);
		}
		else {
			$temper_data_cukl = str_replace('[*active*]', '', $temper_data_cukl);
		}
		
		$compile_code .= $temper_data_cukl;
	}
	$temper_data = $compile_code;
?>