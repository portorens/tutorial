<?php
	//генерация активных периодов

	$row_cards = $this->mysqli->query('SELECT `series` FROM `'.$this->sh.'cards` GROUP BY `series` ORDER BY `series` ASC ');
	$compile_code = '';
	while ($result_cards = $row_cards->fetch_assoc()) {
		$temper_data_cukl = $temper_data;
		foreach ($result_cards as $result_menu_temper_key=>$result_menu_temper) {
			$temper_data_cukl = str_replace('[*'.$result_menu_temper_key.'*]', $result_menu_temper, $temper_data_cukl);
		}
		
		
		$compile_code .= $temper_data_cukl;
	}
	$temper_data = $compile_code;
?>