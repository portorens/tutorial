<?php
	//редактирование карт
	
	if (isset($_POST['do']) && $_POST['do']=='edit_cards') {
		$stop_work = 0;
		//валидация входящий значений
		
		$_POST['cards_status'] = (int) $_POST['cards_status'];
		if ($_POST['cards_status']==0) {
			$this->message_alert .= 'Пожалуйста укажите корректно статус карты<br>';
			$stop_work = 1;
		}
		
		$_POST['id'] = (int) $_POST['id'];
		if ($_POST['id']==0) {
			$this->message_alert .= 'Ошибка передачи данных<br>';
			$stop_work = 1;
		}
				
		if ($stop_work==0) {
		
			$row_cards = $this->mysqli->query('SELECT `grid_id`, `sum`, `series`, `id`, `date_create`, `date_expires`, `activity_period`, `procent`, `activity_period_id` FROM `'.$this->sh.'cards` WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['id']).'" FOR UPDATE ');
			$result_cards = $row_cards->fetch_assoc();
			
			switch ($_POST['cards_status']) {
				case 1:
					$this->mysqli->query('UPDATE `'.$this->sh.'cards` SET `grid_id` = "'.$this->mysqli->real_escape_string($_POST['cards_status']).'", `grid` = (SELECT `name` FROM `c_grid` WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['cards_status']).'" ) WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['id']).'"' ) or $this->message_error = $this->mysqli->error;
					
				    if ($this->message_error=='') {
						$this->mysqli->commit();
						$this->message_success = 'Статус карты успешно изменен';
					}
					else $this->mysqli->rollback();
				    
				    
				    break;
				case 2:
					//если карта не была активной
					if ($result_cards['date_expires']=='' or $result_cards['date_expires']==NULL) {
						
						switch ($result_cards['activity_period_id']) {
							case 1:
							$sql_status = ', `date_expires` = NOW()+ INTERVAL 1 MONTH';
							break;
							case 2:
							$sql_status = ', `date_expires` = NOW()+ INTERVAL 6 MONTH';
							break;
							case 3:
							$sql_status = ', `date_expires` = NOW()+ INTERVAL 1 YEAR';
							break;
						}
						
					}
					else $sql_status = '';
					
				    
				    $this->mysqli->query('UPDATE `'.$this->sh.'cards` SET `grid_id` = "'.$this->mysqli->real_escape_string($_POST['cards_status']).'", `grid` = (SELECT `name` FROM `c_grid` WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['cards_status']).'" )'.$sql_status.' WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['id']).'"' ) or $this->message_error = $this->mysqli->error;
					
				    if ($this->message_error=='') {
						$this->mysqli->commit();
						$this->message_success = 'Статус карты успешно изменен';
					}
					else $this->mysqli->rollback();
				    
				    break;
				case 3:
				    $this->mysqli->query('UPDATE `'.$this->sh.'cards` SET `grid_id` = "'.$this->mysqli->real_escape_string($_POST['cards_status']).'", `grid` = (SELECT `name` FROM `c_grid` WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['cards_status']).'" ) WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['id']).'"' ) or $this->message_error = $this->mysqli->error;
					
				    if ($this->message_error=='') {
						$this->mysqli->commit();
						$this->message_success = 'Статус карты успешно изменен';
					}
					else $this->mysqli->rollback();
				    break;
			}
		
		
		
		
		
		}
	}
	
		$row_cards = $this->mysqli->query('SELECT `grid_id`, `sum`, `series`, `id`, `date_create`, `date_expires`, `activity_period`, `procent` FROM `'.$this->sh.'cards` WHERE `id` = "'.$this->mysqli->real_escape_string($_GET['edit']).'" ');
		if ($row_cards->num_rows==1) {
			$result_cards = $row_cards->fetch_assoc();
			$temper_data_cukl = $temper_data;
			foreach ($result_cards as $result_menu_temper_key=>$result_menu_temper) {
				$temper_data_cukl = str_replace('[*'.$result_menu_temper_key.'*]', $result_menu_temper, $temper_data_cukl);
			}
		
			$temper_data = $temper_data_cukl.'{{table_purchase}}';
		}
?>