<?php
	//создание карт
	
	if (isset($_POST['do']) && $_POST['do']=='new_cards') {
		$stop_work = 0;
		//валидация входящий значений
		
		//серия
		if (!isset($_POST['series']) || trim($_POST['series'])=='') {
			$this->message_alert .= 'не указана серия карт<br>';
			$stop_work = 1;
		}
		else {
			$_POST['series'] = strtolower($_POST['series']);
			preg_match('|^([a-z0-9]{3,6})$|', $_POST['series'], $result_preg);
			if (!isset($result_preg[1])) {
				$this->message_alert .= 'в поле серия разрешены только латинские символы и цифры<br>';
				$stop_work = 1;
			}
		}
		
		$_POST['cols'] = (int) $_POST['cols'];
		if ($_POST['cols']==0) {
			$this->message_alert .= 'Пожалуйста укажите корректно количество выпускаемых карт<br>';
			$stop_work = 1;
		}
		
		$_POST['activity_period'] = (int) $_POST['activity_period'];
		if ($_POST['activity_period']==0) {
			$this->message_alert .= 'Пожалуйста укажите корректно срок окончания активности<br>';
			$stop_work = 1;
		}
		
		if ($stop_work==0) {
			$row_activity_period = $this->mysqli->query('SELECT `id`, `name` FROM `'.$this->sh.'activity_period` WHERE `id` = "'.$this->mysqli->real_escape_string($_POST['activity_period']).'" LIMIT 1 ');
			$result_activity_period = $row_activity_period->fetch_assoc();
			
			//генерируем INSERT запрос
			$sql_insert = '';
			for ($inrement_insert=1; $inrement_insert<=$_POST['cols']; $inrement_insert++) {
				if ($sql_insert!='') $sql_insert .= ',';
				$sql_insert .= '(NOW(), "'.$this->mysqli->real_escape_string($_POST['series']).'", "'.$result_activity_period['id'].'", "'.$result_activity_period['name'].'")';
			}
			
			$this->mysqli->query('INSERT INTO `'.$this->sh.'cards` 
									(
									`date_create`,
									`series`,
									`activity_period_id`,
									`activity_period`
									 ) 
								VALUES '.$sql_insert) or $this->message_error = $this->mysqli->error;
			
			if ($this->message_error=='') {
				$this->mysqli->commit();
				$this->message_success = 'карты успешно созданы';
			}
			else $this->mysqli->rollback();
			
		}
	}

?>