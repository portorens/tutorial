<?php
if (isset($_GET['edit']) && $_GET['edit']!='') {
	$temper_data = '{{edit_cards}}';
}
else {
	$massfiles = array ("name" => "карты",
	"tpl"=>"index.php",
	"sub_menu"=>"sub_menu.php",
	"adr"=>"index",
	"need_to_create_button"=>"yes",
	"onpage"=>"40",
	"search"=>"yes",
	"rules"=>"all",
	"default"=>"no",
	"inrazdel"=>"",
	"filtersusers"=>"no",
	"dopSQL"=>" ORDER BY `id` DESC",
	"dopWHERE"=>'',
	"onoff"=>"on");
	
	$sortirovka[] = array("stolb"=>"series", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"серия");
	$sortirovka[] = array("stolb"=>"id", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"номер");
	$sortirovka[] = array("stolb"=>"date_create", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"дата создания");
	$sortirovka[] = array("stolb"=>"date_expires", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"дата деактивации");
	$sortirovka[] = array("stolb"=>"grid", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"статус карты");
	$sortirovka[] = array("stolb"=>"activity_period", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"период работы");
	$sortirovka[] = array("stolb"=>"procent", "sort"=>"?do=".$_GET['do']."&edit=[[id]]", "stolb_name"=>"процент начисления");
	
	
	if (isset($_GET['search']['series']) && trim($_GET['search']['series'])!='') {
		$_GET['search']['series'] = str_replace('+', ' ', $_GET['search']['series']);
		$massfiles['dopWHERE'] .= ' `series` LIKE "%'.$this->mysqli->real_escape_string($_GET['search']['series']).'%" ';
	}
	if (isset($_GET['search']['grid']) && trim($_GET['search']['grid'])!='') {
		$_GET['search']['grid'] = str_replace('+', ' ', $_GET['search']['grid']);
		if ($massfiles['dopWHERE']!='') $massfiles['dopWHERE'] .= ' and ';
		$massfiles['dopWHERE'] .= ' `grid` LIKE "%'.$this->mysqli->real_escape_string($_GET['search']['grid']).'%" ';
	}
	if (isset($_GET['search']['activity_period']) && trim($_GET['search']['activity_period'])!='') {
		$_GET['search']['activity_period'] = str_replace('+', ' ', $_GET['search']['activity_period']);
		if ($massfiles['dopWHERE']!='') $massfiles['dopWHERE'] .= ' and ';
		$massfiles['dopWHERE'] .= ' `activity_period` LIKE "%'.$this->mysqli->real_escape_string($_GET['search']['activity_period']).'%" ';
	}
	
	$temper_data = '{{search}}'.$this->admin_vkladka($this->sh.'cards', '', $massfiles, $massfiles['dopSQL'], $massfiles['dopWHERE'], $sortirovka);
}
?>
