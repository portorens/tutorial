<?php

$this->mysqli = new mysqli("localhost", $this->db_login, $this->db_password, $this->db_name);
$this->mysqli->autocommit(false);
$this->mysqli->set_charset("utf8");

?>
